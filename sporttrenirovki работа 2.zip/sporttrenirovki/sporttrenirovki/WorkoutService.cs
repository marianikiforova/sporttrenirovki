﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace sporttrenirovki
{
    public class WorkoutService
    {
        private readonly WorkoutContext _context;

        public WorkoutService(WorkoutContext context)
        {
            _context = context;
        }

        // Получить список всех сохранённых тренировок (для выпадающего списка)
        public List<Workout> GetAll()
        {
            return _context.Workouts.ToList();
        }

        // Получить конкретную тренировку вместе с её замерами из БД
        public Workout GetByIdWithSamples(int id)
        {
            return _context.Workouts
                .Include(w => w.Samples)
                .FirstOrDefault(w => w.Id == id);
        }

        // Сохранить новую тренировку в БД
        public void Add(Workout workout)
        {
            _context.Workouts.Add(workout);
            _context.SaveChanges();
        }
    }
}
