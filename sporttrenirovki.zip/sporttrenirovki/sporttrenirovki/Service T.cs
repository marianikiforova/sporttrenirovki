﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace sporttrenirovki
{
    public class Service<T> where T : class
    {
        private readonly WorkoutContext _context;

        public Service(WorkoutContext context)
        {
            _context = context;
        }

        // 1. Получение всех объектов типа T
        public List<T> GetAll()
        {
            return _context.Set<T>().ToList();
        }

        // 2. Получение объекта по идентификатору
        public T? GetById(int id)
        {
            return _context.Set<T>().Find(id);
        }

        // 3. Добавление нового объекта в БД
        public void Add(T entity)
        {
            _context.Set<T>().Add(entity);
            _context.SaveChanges();
        }

        // 4. Фильтрация данных с использованием делегата Predicate<T>
        public List<T> Get(Predicate<T> predicate)
        {
            return _context
                .Set<T>()
                .ToList()
                .FindAll(predicate);
        }
    }
}
