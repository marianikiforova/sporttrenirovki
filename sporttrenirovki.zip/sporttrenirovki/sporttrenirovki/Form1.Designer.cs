﻿namespace sporttrenirovki
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnLoadFile = new Button();
            openFileDialog1 = new OpenFileDialog();
            lblFileName = new Label();
            lblSummary = new Label();
            btnSaveToDb = new Button();
            cmbSavedWorkouts = new ComboBox();
            dgvAnalysis = new DataGridView();
            btnLoadFromDb = new Button();
            lblStatus = new Label();
            txtFilterValue = new TextBox();
            btnFilterSamples = new Button();
            btnShowAllSamples = new Button();
            btnFilterWorkouts = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvAnalysis).BeginInit();
            SuspendLayout();
            // 
            // btnLoadFile
            // 
            btnLoadFile.BackColor = Color.FromArgb(255, 192, 255);
            btnLoadFile.Location = new Point(12, 12);
            btnLoadFile.Name = "btnLoadFile";
            btnLoadFile.Size = new Size(260, 77);
            btnLoadFile.TabIndex = 0;
            btnLoadFile.Text = "Выбрать файл тренировки";
            btnLoadFile.UseVisualStyleBackColor = false;
            btnLoadFile.Click += btnLoadFile_Click;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // lblFileName
            // 
            lblFileName.AutoSize = true;
            lblFileName.Location = new Point(12, 126);
            lblFileName.Name = "lblFileName";
            lblFileName.Size = new Size(124, 20);
            lblFileName.TabIndex = 1;
            lblFileName.Text = "Файл не выбран";
            // 
            // lblSummary
            // 
            lblSummary.AutoSize = true;
            lblSummary.Location = new Point(12, 146);
            lblSummary.Name = "lblSummary";
            lblSummary.Size = new Size(238, 20);
            lblSummary.TabIndex = 2;
            lblSummary.Text = "Общая информация: нет данных";
            // 
            // btnSaveToDb
            // 
            btnSaveToDb.BackColor = Color.FromArgb(255, 192, 192);
            btnSaveToDb.Enabled = false;
            btnSaveToDb.Location = new Point(278, 13);
            btnSaveToDb.Name = "btnSaveToDb";
            btnSaveToDb.Size = new Size(260, 77);
            btnSaveToDb.TabIndex = 5;
            btnSaveToDb.Text = "Сохранить в БД";
            btnSaveToDb.UseVisualStyleBackColor = false;
            btnSaveToDb.Click += btnSaveToDb_Click;
            // 
            // cmbSavedWorkouts
            // 
            cmbSavedWorkouts.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSavedWorkouts.FormattingEnabled = true;
            cmbSavedWorkouts.Location = new Point(12, 95);
            cmbSavedWorkouts.Name = "cmbSavedWorkouts";
            cmbSavedWorkouts.Size = new Size(238, 28);
            cmbSavedWorkouts.TabIndex = 6;
            // 
            // dgvAnalysis
            // 
            dgvAnalysis.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAnalysis.Location = new Point(11, 222);
            dgvAnalysis.Name = "dgvAnalysis";
            dgvAnalysis.RowHeadersWidth = 51;
            dgvAnalysis.Size = new Size(792, 426);
            dgvAnalysis.TabIndex = 4;
            dgvAnalysis.CellContentClick += dgvAnalysis_CellContentClick;
            // 
            // btnLoadFromDb
            // 
            btnLoadFromDb.BackColor = Color.FromArgb(192, 192, 255);
            btnLoadFromDb.Location = new Point(544, 12);
            btnLoadFromDb.Name = "btnLoadFromDb";
            btnLoadFromDb.Size = new Size(260, 77);
            btnLoadFromDb.TabIndex = 7;
            btnLoadFromDb.Text = "Загрузить из БД";
            btnLoadFromDb.UseVisualStyleBackColor = false;
            btnLoadFromDb.Click += btnLoadFromDb_Click;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.ForeColor = Color.Red;
            lblStatus.Location = new Point(12, 166);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(15, 20);
            lblStatus.TabIndex = 3;
            lblStatus.Text = "-";
            // 
            // txtFilterValue
            // 
            txtFilterValue.Location = new Point(11, 189);
            txtFilterValue.Name = "txtFilterValue";
            txtFilterValue.Size = new Size(125, 27);
            txtFilterValue.TabIndex = 8;
            txtFilterValue.TextChanged += txtFilterValue_TextChanged;
            // 
            // btnFilterSamples
            // 
            btnFilterSamples.BackColor = Color.FromArgb(192, 255, 192);
            btnFilterSamples.Location = new Point(420, 189);
            btnFilterSamples.Name = "btnFilterSamples";
            btnFilterSamples.Size = new Size(223, 29);
            btnFilterSamples.TabIndex = 9;
            btnFilterSamples.Text = "Фильтр замеров (высота > X)";
            btnFilterSamples.UseVisualStyleBackColor = false;
            btnFilterSamples.Click += btnFilterSamples_Click;
            // 
            // btnShowAllSamples
            // 
            btnShowAllSamples.BackColor = Color.FromArgb(255, 224, 192);
            btnShowAllSamples.Location = new Point(648, 189);
            btnShowAllSamples.Name = "btnShowAllSamples";
            btnShowAllSamples.Size = new Size(155, 29);
            btnShowAllSamples.TabIndex = 10;
            btnShowAllSamples.Text = "Все замеры из БД";
            btnShowAllSamples.UseVisualStyleBackColor = false;
            btnShowAllSamples.Click += btnShowAllSamples_Click;
            // 
            // btnFilterWorkouts
            // 
            btnFilterWorkouts.BackColor = Color.FromArgb(255, 255, 192);
            btnFilterWorkouts.Location = new Point(143, 189);
            btnFilterWorkouts.Name = "btnFilterWorkouts";
            btnFilterWorkouts.Size = new Size(271, 29);
            btnFilterWorkouts.TabIndex = 11;
            btnFilterWorkouts.Text = "Фильтр тренировок (дистанция > X)";
            btnFilterWorkouts.UseVisualStyleBackColor = false;
            btnFilterWorkouts.Click += btnFilterWorkouts_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 255);
            ClientSize = new Size(816, 642);
            Controls.Add(btnFilterWorkouts);
            Controls.Add(btnShowAllSamples);
            Controls.Add(btnFilterSamples);
            Controls.Add(txtFilterValue);
            Controls.Add(btnLoadFromDb);
            Controls.Add(cmbSavedWorkouts);
            Controls.Add(btnSaveToDb);
            Controls.Add(dgvAnalysis);
            Controls.Add(lblStatus);
            Controls.Add(lblSummary);
            Controls.Add(lblFileName);
            Controls.Add(btnLoadFile);
            Name = "Form1";
            Text = "Анализ тренировок";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvAnalysis).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnLoadFile;
        private OpenFileDialog openFileDialog1;
        private Label lblFileName;
        private Label lblSummary;
        private Button btnSaveToDb;
        private ComboBox cmbSavedWorkouts;
        private DataGridView dgvAnalysis;
        private Button btnLoadFromDb;
        private Label lblStatus;
        private TextBox txtFilterValue;
        private Button btnFilterSamples;
        private Button btnShowAllSamples;
        private Button btnFilterWorkouts;
    }
}
