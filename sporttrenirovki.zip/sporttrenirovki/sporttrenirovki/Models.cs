﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace sporttrenirovki
{
    // ================= МОДЕЛИ ДЛЯ БАЗЫ ДАННЫХ (EF Core) =================

    public class Workout
    {
        [Key]
        public int Id { get; set; }
        public string FileName { get; set; }
        public string Activity { get; set; }
        public string DateTime { get; set; }
        public double Duration { get; set; }
        public double Distance { get; set; }

        // Связь с замерами Варианта 5
        public List<VerticalSampleEntity> Samples { get; set; } = new();

        // Чтобы красиво отображалось в выпадающем списке (ComboBox)
        public override string ToString()
        {
            return $"{Id}: {Activity} ({DateTime}) - {FileName}";
        }
    }

    public class VerticalSampleEntity
    {
        [Key]
        public int Id { get; set; }
        public string TimeISO8601 { get; set; }
        public double VerticalSpeed { get; set; }
        public double Altitude { get; set; }

        // Внешний ключ на тренировку
        public int WorkoutId { get; set; }
        public Workout Workout { get; set; }
    }

    // ================= МОДЕЛИ ДЛЯ ЧТЕНИЯ JSON (из ПР №1) =================

    public class SuuntoFileRoot
    {
        [JsonPropertyName("DeviceLog")]
        public DeviceLogData DeviceLog { get; set; }
    }

    public class DeviceLogData
    {
        [JsonPropertyName("Header")]
        public WorkoutHeader Header { get; set; }

        [JsonPropertyName("Samples")]
        public List<WorkoutSample> Samples { get; set; }
    }

    public class WorkoutHeader
    {
        [JsonPropertyName("Activity")]
        public string Activity { get; set; }

        [JsonPropertyName("ActivityType")]
        public int? ActivityType { get; set; }

        [JsonPropertyName("DateTime")]
        public string DateTime { get; set; }

        [JsonPropertyName("Duration")]
        public double? Duration { get; set; }

        [JsonPropertyName("Distance")]
        public double? Distance { get; set; }
    }

    public class WorkoutSample
    {
        [JsonPropertyName("TimeISO8601")]
        public string TimeISO8601 { get; set; }

        [JsonPropertyName("VerticalSpeed")]
        public double? VerticalSpeed { get; set; }

        [JsonPropertyName("Altitude")]
        public double? Altitude { get; set; }
    }

    // Строка для отображения в таблице DataGridView
    public class VerticalAnalysisRow
    {
        public string Time { get; set; }
        public double VerticalSpeed { get; set; }
        public double Altitude { get; set; }
    }
}
