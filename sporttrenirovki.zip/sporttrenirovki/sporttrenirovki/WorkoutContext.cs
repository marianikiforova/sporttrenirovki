﻿using Microsoft.EntityFrameworkCore;

namespace sporttrenirovki
{
    public class WorkoutContext : DbContext
    {
        public DbSet<Workout> Workouts { get; set; }
        public DbSet<VerticalSampleEntity> VerticalSamples { get; set; }

        public WorkoutContext(DbContextOptions<WorkoutContext> options)
            : base(options)
        {
            // Автоматически создаёт файл БД workouts.db при первом запуске
            Database.EnsureCreated();
        }

        public WorkoutContext()
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlite("Data Source=workouts.db");
            }
        }
    }
}
